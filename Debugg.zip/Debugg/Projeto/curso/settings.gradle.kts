rootProject.name = "curso"
