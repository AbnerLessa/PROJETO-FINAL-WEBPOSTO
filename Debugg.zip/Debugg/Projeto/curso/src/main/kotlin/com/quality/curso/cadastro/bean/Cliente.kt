package com.quality.curso.cadastro.bean

import jakarta.persistence.*
import java.util.*



@Entity
@Table(name = "cliente", schema = "public")
class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Int = 0

    @Column
    var nome : String? = null

    @Column
    var dtnascimento: Date? = null

    @Column
    var sexo: String? = null

    @Column
    var endereco: String? = null

    @Column
    var cidade: String? = null

    @Column
    var ativo: Boolean? = null

    @Column
    var cep: String? = null

    @Column
    var bairro: String? = null

    @Column
    var email: String? = null

}
