package com.quality.curso.cadastro.business

import com.quality.curso.cadastro.bean.Cliente
import com.quality.curso.cadastro.repositories.ClienteRepository
import jakarta.persistence.EntityNotFoundException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("cliente")
class ClienteBusiness {

    @Autowired
    lateinit var clienteRepository: ClienteRepository

    @GetMapping
    fun getAllClientes(): List<Cliente>{
        return clienteRepository.findAll()
    }

    @GetMapping("/{id}")
    fun getCliente(@PathVariable("id") id: Int): Cliente {
        return clienteRepository.findById(id).orElseThrow{EntityNotFoundException()}
    }

    @PostMapping
    fun postCliente(@RequestBody cliente: Cliente): Cliente{
        return clienteRepository.save(cliente)
    }

    @PutMapping("/{id}")
    fun updateCliente(@PathVariable("id") id: Int, @RequestBody cliente: Cliente){
        val clienteUpdate = clienteRepository.findById(id).orElseThrow{EntityNotFoundException()}




        clienteUpdate.nome = cliente.nome
        clienteUpdate.dtnascimento = cliente.dtnascimento
        clienteUpdate.sexo = cliente.sexo
        clienteUpdate.endereco = cliente.endereco
        clienteUpdate.cidade = cliente.cidade
        clienteUpdate.ativo = cliente.ativo
        clienteUpdate.cep = cliente.cep
        clienteUpdate.bairro = cliente.bairro
        clienteUpdate.email = cliente.email
        clienteRepository.save(clienteUpdate)
    }


    @DeleteMapping("/{id}")
    fun deleteCliente(@PathVariable("id") id: Int){
        return clienteRepository.deleteById(id)
    }
}