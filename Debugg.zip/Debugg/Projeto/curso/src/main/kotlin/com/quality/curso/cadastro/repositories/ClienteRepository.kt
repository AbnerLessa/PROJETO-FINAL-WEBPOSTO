package com.quality.curso.cadastro.repositories

import com.quality.curso.cadastro.bean.Cliente
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ClienteRepository: JpaRepository<Cliente, Int> {
}